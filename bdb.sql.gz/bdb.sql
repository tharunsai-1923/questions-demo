-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 05, 2022 at 04:33 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `addevent`
--

CREATE TABLE `addevent` (
  `event` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `email` varchar(30) NOT NULL,
  `password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`email`, `password`) VALUES
('admin', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `otp`
--

CREATE TABLE `otp` (
  `name` varchar(20) NOT NULL,
  `otpp` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `name` varchar(15) NOT NULL,
  `age` varchar(2) NOT NULL,
  `bloodgroup` varchar(3) NOT NULL,
  `phonenumber` varchar(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `pincode` varchar(10) NOT NULL,
  `password` varchar(15) NOT NULL,
  `confirmpassword` varchar(15) NOT NULL,
  `status` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`name`, `age`, `bloodgroup`, `phonenumber`, `email`, `pincode`, `password`, `confirmpassword`, `status`) VALUES
('Karthik', '19', 'O+', '7845672345', 'karthikkc111@gmail.com', '517124', 'Karthik@123', 'Karthik@123', 'yes'),
('deepak', '20', 'A-', '7995521838', 'deepakesikela@gmail.com', '517102', 'Deepak@123', 'Deepak@123', 'yes'),
('Tharunsai', '19', 'A+', '8247054752', 'tharuntharun3524@gmail.com', '517124', 'Tharun@123', 'Tharun@123', 'yes'),
('vijay', '20', 'O+', '8297675122', 'vijaysekhar362@gmail.com', '517102', 'Vijay@123', 'Vijay@123', 'yes'),
('shaiksha', '20', 'O+', '8688251504', 'shaikshavali19102001@gmail.com', '518222', 'Vali@1910', 'Vali@1910', 'yes'),
('Nithish', '20', 'O+', '8978177147', 'nithishkumar9963@gmail.com', '518002', 'Nithish1@', 'Nithish1@', 'yes'),
('Vishnu', '20', 'AB+', '8987654351', 'vishnuvardhan3715@gmail.com', '517102', 'Vishnu@123', 'Vishnu@123', 'yes'),
('Poorna chandu', '20', 'B+', '9000430259', 'rockstarpoorna8@gmail.com', '517102', 'Poorna@123', 'Poorna@123', 'yes'),
('Samba', '19', 'A+', '9347520266', 'sivasivareddy094@gmail.com', '517102', 'Samba@123', 'Samba@123', 'yes'),
('ravindra', '20', 'O+', '9347805393', 'venkatarajaravindra@gmail.com', '517102', 'Ravindra@123', 'Ravindra@123', 'yes'),
('harish', '20', 'O+', '9390000398', 'harishkumarreddyballa@gmail.co', '517102', 'Harish@123', 'Harish@123', 'yes'),
('sreekanth', '20', 'B+', '9502335573', 'msreekanth2580@gmail.com', '517102', 'Sreekanth@123', 'Sreekanth@123', 'yes');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD UNIQUE KEY `phonenumber` (`phonenumber`),
  ADD UNIQUE KEY `email` (`email`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
